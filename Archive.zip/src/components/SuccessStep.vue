<template>
  <v-card>
    <h1>Email Sent Successfully!</h1>
  </v-card>
</template>

<script>
export default {
  name: 'SuccessStep',
  methods: {
  }
}
</script>

<style scoped lang="scss">
</style>
